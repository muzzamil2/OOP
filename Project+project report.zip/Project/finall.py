  #installed 2.2 pip game
import os
import random
import math
import pygame
import sys
#We are adding all these os stuff to dynamically load all of the
#sprite sheets and images 
#So that we dont have to manually like type out the file names that we want

from os import listdir
from os.path import isfile, join
pygame.init()

pygame.display.set_caption("Fox Simulator")
#This is setting the caption at the top of the window

#Global Variables 
Width,height= 700,500
FPS=60
Playervel=5
#the speed of the character moving
window = pygame.display.set_mode((Width, height))

def flip(sprites):
    return [pygame.transform.flip(sprite,True,False) for sprite in sprites]
    #This is indicating which side they want to flip this too true means flips in the x direction and false means dont flip in the y direction

def loadspritesheet(dir1,dir2,width,height,direction=False):
    #this is going to load all the different sprite sheets for our charater eg double jumping ,falling 
    path= join("assets",dir1,dir2)
    images=[f for f in listdir(path) if isfile(join(path,f))]

    allsprites={}

    for image in images:
        spritesheet=pygame.image.load(join(path,image)).convert_alpha()

        sprites =[]
        for i in range(spritesheet.get_width()//width):
            surface=pygame.Surface((width,height),pygame.SRCALPHA,32)
            rect =pygame.Rect(i*width,0,width,height)
            surface.blit(spritesheet,(0,0),rect)
            sprites.append(pygame.transform.scale2x(surface))

        if direction:
            allsprites[image.replace(".png","") + "_right"] = sprites
            allsprites[image.replace(".png","") + "_left"] = flip(sprites)
        else:
            allsprites[image.replace(".png","")] = sprites
            
    return allsprites

def get_block(size):
    path=join("assets","Terrain","Terrain.png")
    #convert alpha is used for transparent background
    image = pygame.image.load(path).convert_alpha()
    #size is the width and height of the surface (below we are creating an image of that size taken as an argument)
    surface=pygame.Surface((size,size),pygame.SRCALPHA,32)
    #96 , 0 is the value of (x,y) part of the image to extract from the png file
    rect=pygame.Rect(96,0,size,size)
    surface.blit(image,(0,0),rect)
    #scale2x is scaling up meaning doubling the size of the image created
    return pygame.transform.scale2x(surface)
      
class Player(pygame.sprite.Sprite):
    color=(255,0,0)
    gravity = 1
    sprites=loadspritesheet("MainCharacters","Fox",32,32,True)
    #amount of delay between each sprite (i.e 5 frames)
    animationdelay=3
    #We use sprite because it makes it easy to do pixel perfect collision when we have two sprite objects 
    #which we are going to have because we are inheriting from pygame sprite class
    #we can use a method that tells us if the sprites are colliding with each other
    def __init__(self,x,y,width,height):
        super().__init__()
        self.rect=pygame.Rect(x,y,width,height)
        self.xvel=0
        self.yvel=0
        #xvel,yvel denotes how fast we are moving our player every single firm in two direction
        #the way we move our player is that we apply a velocity in a direction and keep moving until we remove the velocity
        self.mask=None
        self.direction="left"
        self.animationcount=0
        #we are rsetting that when we change directions cus we dont want to animation to look weird when animation is changing from left to right
        self.fallcount = 0
        self.jumpcount=0
        self.char_hit=False
        self.hitcount=0
        
        self.sprite = self.sprites["Idle_left"][0]
        
    def jump(self):
          self.yvel=-self.gravity*8 #negative sso the character jumps up
          self.animationcount=0
          self.jumpcount+=1
          if self.jumpcount==1:
            self.fallcount=0#any gravity accumulated becomes 0
   
    def move(self,dx,dy):
        #this takes displacemnets in the x and y directions
        self.rect.x +=dx
        self.rect.y +=dy
        
    def hit(self):
        self.char_hit=True
        
    def moveleft(self,vel):
        self.xvel = -vel
        #we use - inorder to move left cus we have to subtract from our x position in pygame 
        #remember pygame coordinates 00 is the top left hand corner of the screen
        #to move right we had to the x coordinate and if want to move up we subtract from our y coordinate
        if self.direction != "left":
            self.direction= "left"
            self.animationcount=0
            
    def moveright(self,vel):
        self.xvel = vel
        if self.direction != "right":
            self.direction= "right"
            self.animationcount=0
    
    def loop(self,fps):
        self.yvel += min(1, (self.fallcount / fps) * self.gravity)
        self.move(self.xvel, self.yvel)
        #this will be called every frame and this is going to move our character in the correct direction
        #this will handle things like updating the animation and all of the stuff we constantly need to do for our character
        if self.char_hit:
            self.hitcount+=1
            
        if self.hitcount>fps*2:
            self.char_hit=False
            self.hitcount=0
      
        self.fallcount += 1
        self.updatesprite()
        
    def landed(self):
        self.fallcount=0
        self.yvel=0
        self.jumpcount=0
        
    def hithead(self):
        self.count=0
        self.yvel*=-1#hit head bounce back and go downwards
        
    
    #to update our sprite or update what we are showing on the screen
    def updatesprite(self):
        spritesheet= "idle" #default spread sheet ( not moving)
        if self.hit:
            spritesheet="hit"
            
        elif self.yvel<0:
            if self.jumpcount==1:
                spritesheet="jump"
            elif self.jumpcount==2:
                spritesheet="double jump"
        elif self.yvel > self.gravity*2:
            spritesheet="fall"
        # if running then
        elif self.xvel!= 0:
            spritesheet="run"
           #sprite sheet to store the running motion (with direction)
            spritesheetname= spritesheet+ "_" + self.direction
           # all the sprites that we could be using for this animation
            Sprites = self.sprites[spritesheetname]
            #new index no.for every animation frame for every sprite we have 
            spriteindex= (self.animationcount//self.animationdelay) % len(Sprites)
            self.sprite = Sprites[spriteindex]
            self.animationcount+=1
            self.update()
    #update the the rectange that bounds our character based on the sprite that we are showing
    def update(self):
           self.rect=self.sprite.get_rect(topleft=(self.rect.x,self.rect.y))
           self.mask= pygame.mask.from_surface(self.sprite)
    def draw(self,win,offsetx):
        win.blit(self.sprite,(self.rect.x-offsetx,self.rect.y)) 
    
#base class for all objects
class object(pygame.sprite.Sprite):
    def __init__(self,x,y,width,height,name=None):
        #properties we need for a valid sprite
        super().__init__()
        self.rect = pygame.Rect(x,y,width,height)
        self.image=pygame.Surface((width,height),pygame.SRCALPHA)
        self.width = width
        self.height=height
        self.name=name
        
    def draw(self,win,offsetx):
        win.blit(self.image,(self.rect.x-offsetx,self.rect.y))
        
class block(object):
    def __init__(self,x,y,size):
        #square so need one dimension only
        super().__init__(x,y,size,size)
        block=get_block(size)
        self.image.blit(block,(0,0))
        self.mask=pygame.mask.from_surface(self.image)
        
class Platform(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height,name):
        super().__init__()
        self.image = pygame.Surface((width, height))
        self.image.fill((159, 85, 41) )  
        self.rect = self.image.get_rect(topleft=(x, y))
        self.mask = pygame.mask.from_surface(self.image)
        self.name=name
    def draw(self, win, offsetx):
        win.blit(self.image, (self.rect.x - offsetx, self.rect.y))
        
class fire(object):
    animationdelay=3
    def __init__(self,x,y,width,height):
        super().__init__(x,y,width,height,"Fire")
        self.fire=loadspritesheet("Traps","Fire",width,height)
        self.image=self.fire["off"][0]
        self.mask=pygame.mask.from_surface(self.image)
        self.animationcount=0
        self.animationname="off"
    def on(self):
        self.animationname="on"
    def off(self):
        self.animationname="off"
    def loop(self):
            #all the sprites that we could be using for this animation
            sprites = self.fire[self.animationname]
            #new index no.for every animation frame for every sprite we have 
            spriteindex= (self.animationcount//self.animationdelay) % len(sprites)
            self.image = sprites[spriteindex]
            self.animationcount+=1
            self.rect=self.image.get_rect(topleft=(self.rect.x,self.rect.y))
            self.mask= pygame.mask.from_surface(self.image)
            #the animation count for fire shouldnt go beyond the length of the sprite otherwise the programm will have glitches
            if self.animationcount//self.animationdelay>len(sprites):
                self.animationcount=0
                
class saw(object):
    animationdelay=3
    def __init__(self,x,y,width,height):
        super().__init__(x,y,width,height,"Saw")
        self.saw=loadspritesheet("Traps","Saw",width,height)
        #self.rect = self.image.get_rect(topleft=(x, y))
        self.image=self.saw["off"][0]
        self.mask=pygame.mask.from_surface(self.image)
        self.animationcount=0
        self.animationname="off"
    def On(self):
        self.animationname="on"
    def Off(self):
        self.animationname="off"
    def loop(self):
           # all the sprites that we could be using for this animation
            sprites = self.saw[self.animationname]
            #new index no.for every animation frame for every sprite we have 
            spriteindex= (self.animationcount//self.animationdelay) % len(sprites)
            self.image = sprites[spriteindex]
            self.animationcount+=1
            self.rect=self.image.get_rect(topleft=(self.rect.x,self.rect.y))
            self.mask= pygame.mask.from_surface(self.image)
            #the animation count for fire shouldnt go beyond the length of the sprite otherwise the programm will have glitches
            if self.animationcount//self.animationdelay>len(sprites):
                self.animationcount=0
            
class Trampoline(object):
    def __init__(self, x, y,width,height):
        super().__init__(x,y,width,height)
        self.image = pygame.image.load(join("assets", "Traps", "Trampoline", "Idle.png")).convert_alpha()
        self.image = pygame.transform.scale(self.image, (width * 2, height * 2))
        self.rect = self.image.get_rect(center=(x, y))
        self.mask = pygame.mask.from_surface(self.image)
        self.name="fire"
         
class spikes(object):
    def __init__(self,x,y,width,height):
        super().__init__(x,y,width,height)
        path=join("assets","Traps","Spike Head","Idle.png")
        self.image = pygame.image.load(path).convert_alpha()
        self.image = pygame.transform.scale(self.image, (width*2, height*2 ))
        self.rect = self.image.get_rect(center=(x, y))
        self.mask = pygame.mask.from_surface(self.image)
        self.speed=4
        self.name="fire"
    def update(self,playerx,playery):
        dx=playerx-self.rect.centerx
        dy=playery-self.rect.centery
        distance = max(1, (dx**2 + dy**2)**0.5) 
        movex=(dx/distance)*self.speed
        movey=(dy/distance)*self.speed
        
        self.rect.x+=movex
        self.rect.y+=movey   
        self.mask = pygame.mask.from_surface(self.image)
    #def draw(self, win):
     #   win.blit(self.image,self.rect)

class Tree(object):
    def __init__(self, x, y, width, height):
        super().__init__(x,y,width,height)  # Call the parent class (Sprite) constructor
        self.image = pygame.image.load(join("assets", "Other", "tree2.png")).convert_alpha()
        self.image = pygame.transform.scale(self.image, (width*2.5, height*2.5))  # Scale the image to the desired size
        self.rect = self.image.get_rect(center=(x, y))  # Set the position of the tree
        self.mask = pygame.mask.from_surface(self.image)
        self.name="fire"

#window=pygame.display.set_mode((Width,height))
#name is going to be the color of the background , this allows us to change the background we are using
def getbackground(name):
    #so the image we plan to load, that image should exists in the directory matlab same folder the code is running in
    #this wouldnt work in cd 
    image=pygame.image.load(join("assets","Background",name))
    _,_,w,h=image.get_rect()
    #When we do this it will give x,y,width,height- we kept underscore in top here denoting we dont care about x , y values
    tiles=[]
#we are going to loop through how many tiles we need to create in x and y direction
    for i in range(Width//w+1):
        #this is telling us how many tiles we need in the x direction to fill the whole screen and just to make sure we dont have any gaps we add 1
        for j in range(height//h+1):
            #Exact same thing for y direction
            pos=(i*w,j*h)
            tiles.append(pos)
            #Denote the position of the top left hand corner of the current tile that we are adding to this tiles list
            #In pygame when you draw something on the screen you draw it from the top left hand corner, so what we will be doing is continually moving the postions
            #based on how this for loop is going so since we multiplying i w and j h we will get exact postion to place every single tile in on the screen
    return tiles,image

def draw(window,background,bgimage,player,objects,offsetx,platforms,timer_text=None):
    #Rn it wil take the background and later it ll take in everything else you want to draw inside of here
    
    # We are looping through every single tile that we have then we are going to draw our imaage at that position
    # which will fill the entire background with the background images 
    for tile in background:
        window.blit(bgimage,tile)
        #we are going to draw the bg image and what we are passing is the position we want to draw it at
        #tuple is going to contain the x-y position
    for obj in objects:
        obj.draw(window,offsetx)
    player.draw(window,offsetx)
    
    for platform in platforms:
        platform.draw(window, offsetx)
    if timer_text:
        window.blit(timer_text, (Width - timer_text.get_width() - 10, 10))

    pygame.display.update()
    #we update so that every single frame come in and we dont have old drawings still on the screen
    
class wood(pygame.sprite.Sprite):
    def __init__(self,x,y):
        super().__init__()
        path=join("assets","MainCharacters","woodcutter","Woodcutter1.png")
        self.image = pygame.image.load(path).convert_alpha()
        self.image = pygame.transform.scale(self.image, (self.image.get_width() * 2.5, self.image.get_height() * 2.5))
        self.rect = self.image.get_rect(center=(x, y))
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = 0.7
    def update(self,playerx,playery):
        dx=playerx-self.rect.centerx
        dy=playery-self.rect.centery
        distance = max(1, (dx**2 + dy**2)**0.5) 
        movex=(dx/distance)*self.speed
        movey=(dy/distance)*self.speed
        
        self.rect.x+=movex
        self.rect.y+=movey   
        self.mask = pygame.mask.from_surface(self.image)
    def draw(self, win):
        win.blit(self.image, self.rect)

        
def vertical_collision(player,objects,dy,platforms):
    collided_objects=[]
    for obj in objects:
        #the if condition tells you if you are colliding with an object
        if pygame.sprite.collide_mask(player,obj):
          #how the player is hitting the object depends how the collision is working
          if dy >0:#moving down
              player.rect.bottom=obj.rect.top
              player.landed()
          elif dy<0:#moving up
              player.rect.top=obj.rect.bottom
              player.hithead()
          collided_objects.append(obj)

    for platform in platforms:
        if pygame.sprite.collide_mask(player, platform):
            if dy > 0:  # Moving down
                player.rect.bottom = platform.rect.top
                player.landed()
            elif dy < 0:  # Moving up
                player.rect.top = platform.rect.bottom
                player.hithead()
            collided_objects.append(platform)
    return collided_objects

def horizontal_collision(player,objects,dx):
    player.move(dx,0) 
    #update mask
    player.update()
    collided_obj=None
    #checking if they would collide with smth if they move in that direction
    for obj in objects:
        if pygame.sprite.collide_mask(player,obj):
            collided_obj=obj
            break
    #move the character back to where it was originally
    player.move(-dx,0)
    player.update()
    return collided_obj
    
def movements(player,objects,platforms):
    keys = pygame.key.get_pressed()
    player.xvel = 0
    collide_left=horizontal_collision(player,objects,-Playervel*2)
    collide_right=horizontal_collision(player,objects,Playervel*2)
    #if we should be able to move left
    if keys[pygame.K_LEFT] and not collide_left:#if the collison doesnot occur then movement is allowed
        player.moveleft(Playervel)
    #if we should be able to move rigth
    if keys[pygame.K_RIGHT] and not collide_right:
        player.moveright(Playervel)
    vertical_collide=vertical_collision(player,objects,player.yvel,platforms)
    to_check=[collide_left,collide_right,*vertical_collide]
    for obj in to_check:
        if obj and obj.name=='fire':
            player.hit()
 
def main(window):
    #in our main is where we are going to write our event loop
    #The event loop will be handling the collision and moving our character,redrawing the window
    clock=pygame.time.Clock()
    background,bgimage=getbackground("jung.jpg")
    blocksize=96
    player1=Player(30,30,50,50)
    #x coordinates means the pic is settled 100 pixels from the left edge of the screen (horizontal position) and y coordinate means the pic is a little above the bottom of the screen
    Fire=fire(100,height-blocksize-64,16,32)
    Fire1=fire(1900,height-blocksize-64,16,32)
    Fire2=fire(3900,height-blocksize-64,16,32)
    Fire3=fire(4500,height-blocksize-64,16,50)
    Fire4=fire(7000,height-blocksize-64,16,32)
    Fire5=fire(7000,height-blocksize-64,16,32)
    Fire6=fire(7000,height-blocksize-64,16,32)
    Fire7=fire(7000,height-blocksize-64,16,32)
    Fire8=fire(7000,height-blocksize-64,16,32)
    Fire.on()
    Fire1.on()
    Fire2.on()
    Fire3.on()
    Fire4.on()
    Fire5.on()
    Fire6.on()
    Fire7.on()
    Fire8.on()
    tramp1=Trampoline(7950,height-blocksize-56,60,60)
    tramp2=Trampoline(1800,height-blocksize-56,60,60)
    tramp3=Trampoline(1500,height-blocksize-56,60,60)
    tramp4=Trampoline(1700,height-blocksize-56,60,60)
    tramp5=Trampoline(1600,height-blocksize-56,60,60)
    tramp6=Trampoline(10300,height-blocksize-56,60,60)
    Saw1=saw(4000,height-blocksize-67,32,50)
    Saw2=saw(5000,height-blocksize-67,32,50)
    Saw3=saw(6000,height-blocksize-67,32,50)
    Saw4=saw(9500,height-blocksize-67,32,50)
    Saw5=saw(10100,height-blocksize-67,32,50)
    spike1=spikes(10,height-blocksize-1,50,50)
    Saw1.On()
    Saw2.On()
    Saw3.On()
    Saw4.On()
    Saw5.On()
    t1=Tree(0,height-blocksize-200,200,200)
    #- width means block size to the left of the screen and positive is to the rigth side, as for the multiplication i it is telling the x coordinate posiition 
    #of the block to be at
    platforms = [
        Platform(1950, height-blocksize-78, 150, 20,"fire"), 
        Platform(2500, height-blocksize-100, 150, 20,"fire") 
    ]
    floor=[block(i*blocksize,height-blocksize,blocksize)for i in range(-Width//blocksize,Width*2//blocksize+200)]
    objects=[*floor,block(blocksize*5,height-blocksize*4,blocksize),block(blocksize*6, height-blocksize*4,blocksize),
                    block(blocksize*8,height-blocksize*2,blocksize),block(blocksize*10,height-blocksize*4,blocksize),
                    block(blocksize*30,height-blocksize*2,blocksize),block(blocksize*31,height-blocksize*3.5,blocksize),
                    block(blocksize*32,height-blocksize*3.5,blocksize),block(blocksize*33,height-blocksize*3.5,blocksize),
                    block(blocksize*34,height-blocksize*3.5,blocksize),block(blocksize*35,height-blocksize*3.5,blocksize),
                    block(blocksize*36,height-blocksize*4.5,blocksize),block(blocksize*37,height-blocksize*4.5,blocksize),
                    block(blocksize*38,height-blocksize*4.5,blocksize),block(blocksize*39,height-blocksize*4.5,blocksize),
                    block(blocksize*50,height-blocksize*2,blocksize),block(blocksize*54,height-blocksize*2,blocksize),
                    block(blocksize*57,height-blocksize*3,blocksize),block(blocksize*58,height-blocksize*4,blocksize),
                    block(blocksize*59,height-blocksize*4,blocksize),
                    block(blocksize*60,height-blocksize*5,blocksize),block(blocksize*61,height-blocksize*4,blocksize),
                    block(blocksize*68,height-blocksize*2,blocksize),block(blocksize*69,height-blocksize*2,blocksize),
                    block(blocksize*75,height-blocksize*2,blocksize),block(blocksize*78,height-blocksize*4,blocksize),
                    block(blocksize*79,height-blocksize*3,blocksize),block(blocksize*80,height-blocksize*3,blocksize),
                    block(blocksize*85,height-blocksize*2,blocksize),block(blocksize*86,height-blocksize*3,blocksize),
                    block(blocksize*87,height-blocksize*4,blocksize),block(blocksize*88,height-blocksize*5,blocksize),
                    block(blocksize*89,height-blocksize*4,blocksize),block(blocksize*90,height-blocksize*3,blocksize),
                    block(blocksize*91,height-blocksize*2,blocksize),block(blocksize*92,height-blocksize*2,blocksize),
                    block(blocksize*94,height-blocksize*2,blocksize),block(blocksize*96,height-blocksize*2,blocksize),
                    block(blocksize*100,height-blocksize*2,blocksize),block(blocksize*100,height-blocksize*4,blocksize),
                    block(blocksize*101,height-blocksize*2,blocksize),block(blocksize*101,height-blocksize*4,blocksize),
                    block(blocksize*102,height-blocksize*2,blocksize),block(blocksize*102,height-blocksize*4,blocksize),
                    block(blocksize*103,height-blocksize*2,blocksize),block(blocksize*103,height-blocksize*4,blocksize),
                    block(blocksize*104,height-blocksize*2,blocksize),block(blocksize*104,height-blocksize*4,blocksize),
                    block(blocksize*110,height-blocksize*2,blocksize),block(blocksize*111,height-blocksize*2,blocksize),
                    block(blocksize*112,height-blocksize*3,blocksize),block(blocksize*113,height-blocksize*4,blocksize),
                    block(blocksize*114,height-blocksize*4,blocksize),block(blocksize*115,height-blocksize*3,blocksize),
                    block(blocksize*116,height-blocksize*4,blocksize),block(blocksize*117,height-blocksize*3,blocksize),
                    block(blocksize*120,height-blocksize*3,blocksize),block(blocksize*122,height-blocksize*3,blocksize),
                    block(blocksize*124,height-blocksize*3,blocksize),block(blocksize*127,height-blocksize*3,blocksize),
                    block(blocksize*130,height-blocksize*3,blocksize),block(blocksize*131,height-blocksize*3,blocksize),
                    block(blocksize*132,height-blocksize*3,blocksize),block(blocksize*133,height-blocksize*3,blocksize),
                    block(blocksize*135,height-blocksize*4,blocksize),block(blocksize*136,height-blocksize*2,blocksize),
                    block(blocksize*140,height-blocksize*3,blocksize),block(blocksize*141,height-blocksize*2,blocksize),
                    block(blocksize*142,height-blocksize*2,blocksize),block(blocksize*147,height-blocksize*4,blocksize),
                    block(blocksize*148,height-blocksize*4,blocksize),block(blocksize*149,height-blocksize*4,blocksize),
                    block(blocksize*155,height-blocksize*2,blocksize),block(blocksize*155,height-blocksize*3,blocksize),
                    block(blocksize*156,height-blocksize*3,blocksize),block(blocksize*160,height-blocksize*2,blocksize),
                    block(blocksize*168,height-blocksize*4,blocksize),block(blocksize*170,height-blocksize*4,blocksize),
                    block(blocksize*171,height-blocksize*4,blocksize),block(blocksize*172,height-blocksize*4,blocksize),
                    block(blocksize*180,height-blocksize*2,blocksize),block(blocksize*183,height-blocksize*2,blocksize),
                    block(blocksize*185,height-blocksize*2,blocksize),block(blocksize*188,height-blocksize*2,blocksize),
                    block(blocksize*195,height-blocksize*4,blocksize),block(blocksize*200,height-blocksize*4,blocksize),
                    block(blocksize*202,height-blocksize*3,blocksize),block(blocksize*204,height-blocksize*3,blocksize),
                    block(blocksize*205,height-blocksize*3,blocksize),block(blocksize*206,height-blocksize*3,blocksize),
                    block(blocksize*207,height-blocksize*3,blocksize),block(blocksize*210,height-blocksize*2,blocksize),
                    block(blocksize*212,height-blocksize*2,blocksize),block(blocksize*214,height-blocksize*3,blocksize),
                    block(blocksize*216,height-blocksize*2,blocksize),block(blocksize*218,height-blocksize*3,blocksize),
                    block(blocksize*220,height-blocksize*2,blocksize),block(blocksize*226,height-blocksize*4,blocksize),
                    block(blocksize*227,height-blocksize*4,blocksize),block(blocksize*228,height-blocksize*4,blocksize),
                    block(blocksize*229,height-blocksize*4,blocksize),block(blocksize*230,height-blocksize*4,blocksize),
                    block(blocksize*232,height-blocksize*3,blocksize),block(blocksize*233,height-blocksize*3,blocksize),
                    block(blocksize*234,height-blocksize*3,blocksize),block(blocksize*235,height-blocksize*3,blocksize),
                    block(blocksize*237,height-blocksize*2,blocksize),block(blocksize*238,height-blocksize*2,blocksize),
                    block(blocksize*239,height-blocksize*2,blocksize),block(blocksize*240,height-blocksize*2,blocksize),
                    block(blocksize*245,height-blocksize*2,blocksize),block(blocksize*247,height-blocksize*2,blocksize),
                    block(blocksize*249,height-blocksize*2,blocksize),block(blocksize*251,height-blocksize*2,blocksize),
                    block(blocksize*258,height-blocksize*4,blocksize),block(blocksize*259,height-blocksize*4,blocksize),
                    block(blocksize*259,height-blocksize*4,blocksize),block(blocksize*261,height-blocksize*4,blocksize),
                    block(blocksize*262,height-blocksize*4,blocksize),block(blocksize*265,height-blocksize*3,blocksize),
                    block(blocksize*266,height-blocksize*3,blocksize),block(blocksize*267,height-blocksize*3,blocksize),
                    block(blocksize*268,height-blocksize*3,blocksize),block(blocksize*270,height-blocksize*4,blocksize),
                    block(blocksize*271,height-blocksize*4,blocksize),block(blocksize*272,height-blocksize*4,blocksize),
                    block(blocksize*278,height-blocksize*3,blocksize),block(blocksize*279,height-blocksize*3,blocksize),
                    block(blocksize*280,height-blocksize*3,blocksize),block(blocksize*281,height-blocksize*3,blocksize),
                    block(blocksize*283,height-blocksize*3,blocksize),block(blocksize*285,height-blocksize*3,blocksize),
                    block(blocksize*290,height-blocksize*2,blocksize),block(blocksize*290,height-blocksize*3,blocksize),
                    block(blocksize*295,height-blocksize*3,blocksize),block(blocksize*296,height-blocksize*4,blocksize),
                    block(blocksize*298,height-blocksize*2,blocksize),block(blocksize*300,height-blocksize*2,blocksize),
                    Fire,Fire1,Fire2,Fire3,Fire4,Fire5,Fire6,Fire7,Fire8,Saw1,Saw2,Saw3,Saw4,Saw5,t1,tramp1,tramp2,tramp3,tramp4,tramp5,tramp6,spike1]
    offsetx=0
    scrollareawidth=200
    
    starttime = pygame.time.get_ticks()
    totaltime = 60000

    gamestate = "running"

    run=True
    while run:
        clock.tick(FPS)

        elapsedtime = pygame.time.get_ticks() - starttime
        remainingtime = max(0, (totaltime - elapsedtime) // 1000)

        if remainingtime == 0:
            gamestate = "won"

        #Ensures our while loop is going to run 60 frames per second
        for event in pygame.event.get():
            #First event we are going to check for is if user quits game
            #By exit we mean if user clicks red x button on top right corner
            if event.type==pygame.QUIT:
                run=False
                break
            if event.type == pygame.KEYDOWN:
                if event.key==pygame.K_SPACE and player1.jumpcount<2:#<2 indicates double jumping 
                    player1.jump()
        if gamestate == "running":
            player1.loop(FPS)
            Fire.loop()
            Fire1.loop()
            Fire2.loop()
            Fire3.loop()
            Fire4.loop()
            Fire5.loop()
            Fire6.loop()
            Fire7.loop()
            Fire8.loop()
            Saw1.loop()
            Saw2.loop()
            Saw3.loop()
            Saw4.loop()
            Saw5.loop()
            movements(player1,objects,platforms)
            spike1.update(player1.rect.centerx, player1.rect.centery)
            if player1.rect.colliderect(spike1): #pygame.sprite.collide_mask(w1, player1):
               window.fill((0, 0, 0))  # Black background
               font = pygame.font.Font(None, 74)
               lose_text = font.render("You Lost!", True, (255, 0, 0))  # Red text for loss
               text_rect = lose_text.get_rect(center=(Width // 2, height // 2))
               window.blit(lose_text, text_rect)
               pygame.display.update()
               pygame.time.delay(3000)
               break
               
            if player1.rect.colliderect(Saw1) or player1.rect.colliderect(Saw2):
               window.fill((0, 0, 0))  # Black background
               font = pygame.font.Font(None, 74)
               lose_text = font.render("You Lost!", True, (255, 0, 0))  # Red text for loss
               text_rect = lose_text.get_rect(center=(Width // 2, height // 2))
               window.blit(lose_text, text_rect)
               pygame.display.update()
               pygame.time.delay(3000)
               break
            if player1.rect.colliderect(Fire) or player1.rect.colliderect(Fire1) or player1.rect.colliderect(Fire2):
               window.fill((0, 0, 0))  # Black background
               font = pygame.font.Font(None, 74)
               lose_text = font.render("You Lost!", True, (255, 0, 0))  # Red text for loss
               text_rect = lose_text.get_rect(center=(Width // 2, height // 2))
               window.blit(lose_text, text_rect)
               pygame.display.update()
               pygame.time.delay(3000)
               break
            font = pygame.font.Font(None, 36)
            timer_text = font.render(f"Time: {remainingtime}", True, (255, 219, 187))
            draw(window,background,bgimage,player1,objects,offsetx,platforms,timer_text)
     
        if gamestate == "won":
          window.fill((0, 0, 0))  
          font = pygame.font.Font(None, 74)
          win_text = font.render("You Won!", True, (0, 255, 0))
          text_rect = win_text.get_rect(center=(Width // 2, height // 2))
          window.blit(win_text, text_rect)
          pygame.display.update()
          pygame.time.delay(3000)
          break
        #checking if the character is moving to the right if x vel is > 0 then yes player1.rect.right-offsetx
        #this checks if the character is on the screen by subtracting the right position of the character with the offset value   
        
        if ((player1.rect.right-offsetx>=Width-scrollareawidth and player1.xvel>0) or (player1.rect.left-offsetx<=scrollareawidth and player1.xvel<0)):
            #when value of offset will be positive it will move the bg to the left and if negative it will move to the right meaning the character is moving towards left side 
             offsetx+=player1.xvel
             
        if remainingtime <= 0:
            print("Time's up! Game over")
            run = False

        pygame.display.update()
    pygame.quit()
    sys.exit()
    quit()
if __name__ =="__main__":
    #we only call the main function if we run this file directly 
    main(window)




    

